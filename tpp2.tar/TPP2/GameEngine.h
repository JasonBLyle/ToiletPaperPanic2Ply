/*
    Nikita Tran
    CPSC 4160 2D Game Engine Construction
    Assignment 3
    October 23 2020
*/

#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include <SDL2/SDL.h>
#include "Player.h"
#include "Background.h"
#include "PushableObj.h"
#include "HealthObj.h"

class GameEngine{
    private:
        static GameEngine *instance;
        GameEngine();

        SDL_Renderer *renderer;
        SDL_Window *window;
        int screenW; //width of the game window
        int screenH; //height of the game window
        Background bg;//Background change
        SDL_Rect camera;//Background change
        bool runningState;
        bool paused;

    public:
        static GameEngine *GetInstance();

        int GetScreenWidth();
        int GetScreenHeight();
        int GetCameraX();//Background change
        int GetCameraY();//Background change
        int GetCameraWidth();//Background change
        int GetCameraHeight();//Background change
        int getBgWidth();//Background change
        int getBgHeight();//Background change
        void setCamera(int,int,int,int);//Background change
        void setCameraX(int);//Background change
        void setCameraY(int);//Background change
        SDL_Renderer* GetRenderer();
        SDL_Window* GetWindow();
        bool GetRunningState();

        void SetRunningState(bool state);

        void Init(const int w, const int h);
        void HandleEvents();
        void Update();
        void Render();
        void Quit();

        bool IsColliding(SDL_Rect a, SDL_Rect b);
};

#endif
